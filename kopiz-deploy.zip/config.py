import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

class Config:
    db_path = (BASE_DIR / 'kopiz.db').as_posix()
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', f"sqlite:///{db_path}")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = BASE_DIR / 'static' / 'uploads'
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # Maksimal 5MB
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
    TIMEZONE = 'Asia/Jakarta'
