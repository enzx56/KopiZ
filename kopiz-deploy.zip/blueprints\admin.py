import os
import csv
import io
from datetime import datetime, date, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app, Response
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from models import db, User, Product, Category, PreOrder, PreOrderProduct, Order, OrderItem, Customer, OrderStatusHistory, InventoryMovement, Setting
from helpers import slugify, format_rupiah, format_datetime, normalize_phone

admin_bp = Blueprint('admin', __name__)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_user_id' not in session:
            flash('Silakan login terlebih dahulu untuk mengakses dashboard admin.', 'warning')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

# ================= AUTH =================
@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'admin_user_id' in session:
        return redirect(url_for('admin.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        user = User.query.filter_by(email=email, is_active=True).first()
        if user and check_password_hash(user.password_hash, password):
            session['admin_user_id'] = user.id
            session['admin_name'] = user.name
            session['admin_role'] = user.role
            user.last_login_at = datetime.utcnow()
            db.session.commit()
            flash(f'Selamat datang kembali, {user.name}!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Email atau password salah.', 'danger')

    return render_template('admin/login.html')

@admin_bp.route('/logout')
def logout():
    session.clear()
    flash('Anda telah berhasil keluar.', 'info')
    return redirect(url_for('admin.login'))

# ================= DASHBOARD =================
@admin_bp.route('/')
@login_required
def dashboard():
    today = date.today()
    start_of_today = datetime.combine(today, datetime.min.time())
    
    # 1. Metrik Operasional Realtime
    orders_today_count = Order.query.filter(Order.order_date >= start_of_today).count()
    pending_orders_count = Order.query.filter_by(status='PENDING').count()
    processing_orders_count = Order.query.filter(Order.status.in_(['CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP'])).count()
    completed_orders_count = Order.query.filter_by(status='COMPLETED').count()
    active_po_count = PreOrder.query.filter_by(status='OPEN').count()
    active_products_count = Product.query.filter_by(is_active=True, archived_at=None).count()

    # 2. Total Omset Pesanan Selesai Hari Ini & Total Omset Terkonfirmasi
    completed_revenue = db.session.query(db.func.sum(Order.total_amount)).filter(
        Order.status == 'COMPLETED'
    ).scalar() or 0

    # 3. Pesanan Terbaru
    recent_orders = Order.query.order_by(Order.order_date.desc()).limit(8).all()

    # 4. Produk Terlaris (Top Selling Items)
    top_items = db.session.query(
        OrderItem.product_name_snapshot,
        db.func.sum(OrderItem.quantity).label('total_qty'),
        db.func.sum(OrderItem.subtotal).label('total_sales')
    ).join(Order, OrderItem.order_id == Order.id)\
     .filter(Order.status != 'CANCELLED')\
     .group_by(OrderItem.product_name_snapshot)\
     .order_by(db.desc('total_qty'))\
     .limit(5).all()

    return render_template('admin/dashboard.html',
                           orders_today_count=orders_today_count,
                           pending_orders_count=pending_orders_count,
                           processing_orders_count=processing_orders_count,
                           completed_orders_count=completed_orders_count,
                           active_po_count=active_po_count,
                           active_products_count=active_products_count,
                           completed_revenue=completed_revenue,
                           recent_orders=recent_orders,
                           top_items=top_items)

# ================= PRODUK & KATEGORI =================
@admin_bp.route('/products')
@login_required
def products():
    search = request.args.get('q', '').strip()
    status_filter = request.args.get('status', '')
    
    query = Product.query.filter(Product.archived_at == None)
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))
    if status_filter:
        query = query.filter_by(status=status_filter)
        
    products = query.order_by(Product.id.desc()).all()
    categories = Category.query.all()
    return render_template('admin/products/index.html', products=products, categories=categories, search=search, status_filter=status_filter)

@admin_bp.route('/products/create', methods=['GET', 'POST'])
@login_required
def product_create():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        sku = request.form.get('sku', '').strip() or None
        category_id = request.form.get('category_id') or None
        price = int(request.form.get('price', 0))
        short_desc = request.form.get('short_description', '').strip()
        desc = request.form.get('description', '').strip()
        status = request.form.get('status', 'READY')
        track_inventory = True if request.form.get('track_inventory') else False
        stock_quantity = int(request.form.get('stock_quantity', 0))
        is_featured = True if request.form.get('is_featured') else False

        slug = slugify(name)
        # Handle collision
        existing_slug = Product.query.filter_by(slug=slug).first()
        if existing_slug:
            slug = f"{slug}-{int(datetime.utcnow().timestamp())}"

        # Image Upload
        image_path = request.form.get('image_url', '').strip()
        if 'image_file' in request.files:
            file = request.files['image_file']
            if file and file.filename != '':
                filename = secure_filename(file.filename)
                ext = filename.rsplit('.', 1)[-1].lower()
                if ext in current_app.config['ALLOWED_EXTENSIONS']:
                    new_filename = f"prod_{int(datetime.utcnow().timestamp())}_{filename}"
                    file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], new_filename))
                    image_path = f"/static/uploads/{new_filename}"

        product = Product(
            name=name,
            slug=slug,
            sku=sku,
            category_id=category_id,
            price=price,
            short_description=short_desc,
            description=desc,
            image_path=image_path or "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80",
            status=status,
            track_inventory=track_inventory,
            stock_quantity=stock_quantity,
            is_featured=is_featured,
            is_active=True
        )
        db.session.add(product)
        db.session.commit()
        flash(f'Produk "{name}" berhasil ditambahkan!', 'success')
        return redirect(url_for('admin.products'))

    categories = Category.query.filter_by(is_active=True).all()
    return render_template('admin/products/form.html', product=None, categories=categories)

@admin_bp.route('/products/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def product_edit(id):
    product = Product.query.get_or_404(id)
    if request.method == 'POST':
        product.name = request.form.get('name', '').strip()
        product.sku = request.form.get('sku', '').strip() or None
        product.category_id = request.form.get('category_id') or None
        product.price = int(request.form.get('price', product.price))
        product.short_description = request.form.get('short_description', '').strip()
        product.description = request.form.get('description', '').strip()
        product.status = request.form.get('status', product.status)
        product.track_inventory = True if request.form.get('track_inventory') else False
        product.stock_quantity = int(request.form.get('stock_quantity', 0))
        product.is_featured = True if request.form.get('is_featured') else False

        image_url = request.form.get('image_url', '').strip()
        if image_url:
            product.image_path = image_url

        if 'image_file' in request.files:
            file = request.files['image_file']
            if file and file.filename != '':
                filename = secure_filename(file.filename)
                ext = filename.rsplit('.', 1)[-1].lower()
                if ext in current_app.config['ALLOWED_EXTENSIONS']:
                    new_filename = f"prod_{int(datetime.utcnow().timestamp())}_{filename}"
                    file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], new_filename))
                    product.image_path = f"/static/uploads/{new_filename}"

        db.session.commit()
        flash(f'Perubahan produk "{product.name}" berhasil disimpan!', 'success')
        return redirect(url_for('admin.products'))

    categories = Category.query.filter_by(is_active=True).all()
    return render_template('admin/products/form.html', product=product, categories=categories)

@admin_bp.route('/products/<int:id>/archive', methods=['POST'])
@login_required
def product_archive(id):
    product = Product.query.get_or_404(id)
    product.archived_at = datetime.utcnow()
    product.is_active = False
    db.session.commit()
    flash(f'Produk "{product.name}" berhasil diarsipkan.', 'info')
    return redirect(url_for('admin.products'))

# ================= KATEGORI =================
@admin_bp.route('/categories', methods=['GET', 'POST'])
@login_required
def categories():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        desc = request.form.get('description', '').strip()
        if name:
            slug = slugify(name)
            cat = Category(name=name, slug=slug, description=desc)
            db.session.add(cat)
            db.session.commit()
            flash(f'Kategori "{name}" berhasil dibuat!', 'success')
            return redirect(url_for('admin.categories'))

    categories = Category.query.order_by(Category.sort_order.asc()).all()
    return render_template('admin/categories/index.html', categories=categories)

# ================= PRE-ORDERS (PO) =================
@admin_bp.route('/pre-orders')
@login_required
def pre_orders():
    pos = PreOrder.query.order_by(PreOrder.starts_at.desc()).all()
    return render_template('admin/pre_orders/index.html', pre_orders=pos)

@admin_bp.route('/pre-orders/create', methods=['GET', 'POST'])
@login_required
def pre_order_create():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        desc = request.form.get('description', '').strip()
        quota_units = int(request.form.get('quota_units', 50))
        starts_at = datetime.fromisoformat(request.form.get('starts_at'))
        ends_at = datetime.fromisoformat(request.form.get('ends_at'))
        pickup_at = datetime.fromisoformat(request.form.get('pickup_at'))
        status = request.form.get('status', 'OPEN')
        selected_product_ids = request.form.getlist('product_ids')
        banner_path = request.form.get('banner_url', '').strip() or "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1200&q=80"

        slug = slugify(name)
        if PreOrder.query.filter_by(slug=slug).first():
            slug = f"{slug}-{int(datetime.utcnow().timestamp())}"

        po = PreOrder(
            name=name,
            slug=slug,
            description=desc,
            banner_path=banner_path,
            starts_at=starts_at,
            ends_at=ends_at,
            pickup_at=pickup_at,
            quota_units=quota_units,
            reserved_units=0,
            status=status,
            created_by=session.get('admin_user_id'),
            published_at=datetime.utcnow()
        )
        db.session.add(po)
        db.session.flush()

        for pid in selected_product_ids:
            prod = Product.query.get(pid)
            if prod:
                pop = PreOrderProduct(
                    pre_order_id=po.id,
                    product_id=prod.id,
                    price=prod.price,
                    max_quantity_per_order=10
                )
                db.session.add(pop)

        db.session.commit()
        flash(f'Pre-Order "{name}" berhasil dibuka/dibuat!', 'success')
        return redirect(url_for('admin.pre_orders'))

    products = Product.query.filter_by(is_active=True, archived_at=None).all()
    return render_template('admin/pre_orders/form.html', po=None, products=products)

@admin_bp.route('/pre-orders/<int:id>/status', methods=['POST'])
@login_required
def pre_order_status(id):
    po = PreOrder.query.get_or_404(id)
    new_status = request.form.get('status')
    if new_status in ['DRAFT', 'SCHEDULED', 'OPEN', 'CLOSED', 'SOLD_OUT', 'COMPLETED', 'CANCELLED']:
        po.status = new_status
        db.session.commit()
        flash(f'Status Pre-Order diperbarui menjadi {new_status}.', 'success')
    return redirect(url_for('admin.pre_orders'))

# ================= ORDERS & OPERASIONAL =================
@admin_bp.route('/orders')
@login_required
def orders():
    status_filter = request.args.get('status', '')
    type_filter = request.args.get('type', '')
    search = request.args.get('q', '').strip()
    date_filter = request.args.get('date', '')

    query = Order.query.join(Customer)

    if status_filter:
        query = query.filter(Order.status == status_filter)
    if type_filter:
        query = query.filter(Order.order_type == type_filter)
    if search:
        query = query.filter(
            (Order.order_code.ilike(f"%{search}%")) |
            (Customer.name.ilike(f"%{search}%")) |
            (Customer.phone.ilike(f"%{search}%"))
        )
    if date_filter:
        try:
            d = datetime.fromisoformat(date_filter).date()
            start = datetime.combine(d, datetime.min.time())
            end = datetime.combine(d, datetime.max.time())
            query = query.filter(Order.order_date.between(start, end))
        except Exception:
            pass

    orders = query.order_by(Order.order_date.desc()).all()
    return render_template('admin/orders/index.html',
                           orders=orders,
                           status_filter=status_filter,
                           type_filter=type_filter,
                           search=search,
                           date_filter=date_filter)

@admin_bp.route('/orders/<int:id>')
@login_required
def order_detail(id):
    order = Order.query.get_or_404(id)
    customer = Customer.query.get(order.customer_id)
    items = OrderItem.query.filter_by(order_id=order.id).all()
    histories = OrderStatusHistory.query.filter_by(order_id=order.id).order_by(OrderStatusHistory.created_at.asc()).all()

    return render_template('admin/orders/detail.html',
                           order=order,
                           customer=customer,
                           items=items,
                           histories=histories)

@admin_bp.route('/orders/<int:id>/status', methods=['POST'])
@login_required
def order_update_status(id):
    order = Order.query.with_for_update().get_or_404(id)
    new_status = request.form.get('status')
    note = request.form.get('note', '').strip()
    admin_name = session.get('admin_name', 'Admin')

    valid_statuses = ['PENDING', 'CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'COMPLETED', 'CANCELLED']
    if new_status not in valid_statuses:
        flash('Status pesanan tidak valid.', 'danger')
        return redirect(url_for('admin.order_detail', id=order.id))

    old_status = order.status
    if old_status == new_status:
        flash('Status tidak berubah.', 'info')
        return redirect(url_for('admin.order_detail', id=order.id))

    # Aturan Transisi PRD: jika CANCELLED pada Pre-Order, kembalikan kuota unit
    if new_status == 'CANCELLED' and order.order_type == 'PREORDER' and order.pre_order_id:
        po = PreOrder.query.get(order.pre_order_id)
        if po:
            order_units = sum(it.quantity for it in order.items)
            po.reserved_units = max(0, po.reserved_units - order_units)
            if po.status == 'SOLD_OUT' and po.reserved_units < po.quota_units:
                po.status = 'OPEN'

    # Kurangi stok jika dikonfirmasi (untuk produk tracking stok)
    if new_status == 'CONFIRMED' and old_status == 'PENDING':
        for it in order.items:
            if it.product_id:
                prod = Product.query.get(it.product_id)
                if prod and prod.track_inventory:
                    prod.stock_quantity = max(0, prod.stock_quantity - it.quantity)
                    im = InventoryMovement(
                        product_id=prod.id,
                        movement_type='OUT',
                        quantity_change=-it.quantity,
                        reference_type='ORDER',
                        reference_id=order.order_code,
                        note=f"Pengurangan stok untuk pesanan {order.order_code}",
                        created_by=admin_name
                    )
                    db.session.add(im)

    order.status = new_status
    if new_status == 'CONFIRMED':
        order.confirmed_at = datetime.utcnow()
    elif new_status == 'COMPLETED':
        order.completed_at = datetime.utcnow()
    elif new_status == 'CANCELLED':
        order.cancelled_at = datetime.utcnow()

    # Catat Riwayat
    history = OrderStatusHistory(
        order_id=order.id,
        from_status=old_status,
        to_status=new_status,
        changed_by=admin_name,
        note=note or f"Perubahan status oleh {admin_name}"
    )
    db.session.add(history)
    db.session.commit()

    flash(f'Status pesanan #{order.order_code} berhasil diperbarui ke {new_status}!', 'success')
    return redirect(url_for('admin.order_detail', id=order.id))

# ================= PELANGGAN =================
@admin_bp.route('/customers')
@login_required
def customers():
    search = request.args.get('q', '').strip()
    query = Customer.query
    if search:
        query = query.filter((Customer.name.ilike(f"%{search}%")) | (Customer.phone.ilike(f"%{search}%")))

    customers_list = query.order_by(Customer.id.desc()).all()
    
    # Hitung agregasi per pelanggan
    cust_data = []
    for c in customers_list:
        orders = Order.query.filter_by(customer_id=c.id).all()
        completed_orders = [o for o in orders if o.status == 'COMPLETED']
        total_spent = sum(o.total_amount for o in completed_orders)
        cust_data.append({
            'customer': c,
            'total_orders': len(orders),
            'completed_orders': len(completed_orders),
            'total_spent': total_spent,
            'last_order': orders[0].order_date if orders else None
        })

    return render_template('admin/customers/index.html', customers=cust_data, search=search)

# ================= LAPORAN & CSV EXPORT =================
@admin_bp.route('/reports')
@login_required
def reports():
    start_date_str = request.args.get('start_date', '')
    end_date_str = request.args.get('end_date', '')
    status_filter = request.args.get('status', '')
    type_filter = request.args.get('type', '')

    query = Order.query.join(Customer)

    if start_date_str:
        sdate = datetime.fromisoformat(start_date_str)
        query = query.filter(Order.order_date >= sdate)
    if end_date_str:
        edate = datetime.combine(datetime.fromisoformat(end_date_str).date(), datetime.max.time())
        query = query.filter(Order.order_date <= edate)
    if status_filter:
        query = query.filter(Order.status == status_filter)
    if type_filter:
        query = query.filter(Order.order_type == type_filter)

    filtered_orders = query.order_by(Order.order_date.desc()).all()

    # Ringkasan Metrik Sesuai PRD Bagian 18
    total_orders = len(filtered_orders)
    completed_orders = [o for o in filtered_orders if o.status == 'COMPLETED']
    cancelled_orders = [o for o in filtered_orders if o.status == 'CANCELLED']
    total_revenue_completed = sum(o.total_amount for o in completed_orders)
    total_value_all = sum(o.total_amount for o in filtered_orders if o.status != 'CANCELLED')
    total_units_sold = sum(
        sum(it.quantity for it in o.items)
        for o in completed_orders
    )

    return render_template('admin/reports/index.html',
                           orders=filtered_orders,
                           total_orders=total_orders,
                           completed_count=len(completed_orders),
                           cancelled_count=len(cancelled_orders),
                           total_revenue_completed=total_revenue_completed,
                           total_value_all=total_value_all,
                           total_units_sold=total_units_sold,
                           start_date=start_date_str,
                           end_date=end_date_str,
                           status_filter=status_filter,
                           type_filter=type_filter)

@admin_bp.route('/reports/export-csv')
@login_required
def export_csv():
    start_date_str = request.args.get('start_date', '')
    end_date_str = request.args.get('end_date', '')
    status_filter = request.args.get('status', '')
    type_filter = request.args.get('type', '')

    query = Order.query.join(Customer)
    if start_date_str:
        query = query.filter(Order.order_date >= datetime.fromisoformat(start_date_str))
    if end_date_str:
        edate = datetime.combine(datetime.fromisoformat(end_date_str).date(), datetime.max.time())
        query = query.filter(Order.order_date <= edate)
    if status_filter:
        query = query.filter(Order.status == status_filter)
    if type_filter:
        query = query.filter(Order.order_type == type_filter)

    orders = query.order_by(Order.order_date.desc()).all()

    # Format CSV dengan UTF-8 BOM untuk kompatibilitas Excel
    output = io.StringIO()
    output.write('\ufeff') # UTF-8 BOM
    writer = csv.writer(output, delimiter=';')

    writer.writerow(['LAPORAN TRANSAKSI KOPIZ'])
    writer.writerow(['Diekspor pada', datetime.utcnow().strftime('%d-%m-%Y %H:%M:%S UTC')])
    writer.writerow(['Filter Status', status_filter or 'Semua'])
    writer.writerow(['Filter Tipe', type_filter or 'Semua'])
    writer.writerow([])
    writer.writerow(['Kode Pesanan', 'Tanggal', 'Pelanggan', 'No WhatsApp', 'Tipe', 'Item & Qty', 'Total (IDR)', 'Status', 'Catatan'])

    for o in orders:
        items_str = ", ".join([f"{it.product_name_snapshot} ({it.quantity}x)" for it in o.items])
        writer.writerow([
            o.order_code,
            format_datetime(o.order_date),
            o.customer.name,
            o.customer.phone,
            o.order_type,
            items_str,
            o.total_amount,
            o.status,
            o.customer_notes or '-'
        ])

    csv_data = output.getvalue()
    filename = f"laporan_kopiz_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"

    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

# ================= PENGATURAN BRAND & KONTEN =================
@admin_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        for key in request.form:
            val = request.form.get(key, '').strip()
            setting = Setting.query.filter_by(key=key).first()
            if setting:
                setting.value = val
            else:
                db.session.add(Setting(key=key, value=val, is_public=True))
        db.session.commit()
        flash('Pengaturan brand & kontak berhasil disimpan!', 'success')
        return redirect(url_for('admin.settings'))

    all_settings = {s.key: s.value for s in Setting.query.all()}
    return render_template('admin/settings/index.html', settings=all_settings)
