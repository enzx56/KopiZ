import os
from flask import Flask
from config import Config
from models import db
from helpers import format_rupiah, format_datetime, get_setting

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Pastikan direktori uploads tersedia
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Inisialisasi Database
    db.init_app(app)

    # Daftarkan Custom Filter Jinja2
    app.jinja_env.filters['rupiah'] = format_rupiah
    app.jinja_env.filters['datetime'] = format_datetime

    # Context processor untuk data global publik (Brand name, kontak WA, Instagram)
    @app.context_processor
    def inject_global_settings():
        return {
            'brand_name': get_setting('brand_name', 'KopiZ'),
            'brand_tagline': get_setting('brand_tagline', 'Kopinya Gen-Z'),
            'brand_moto': get_setting('brand_moto', 'Kopi Berkualitas, Harga Pas'),
            'whatsapp_number': get_setting('whatsapp_number', '081234567890'),
            'instagram_handle': get_setting('instagram_handle', 'kopiz.id'),
            'instagram_url': get_setting('instagram_url', 'https://instagram.com/kopiz.id'),
            'operating_hours': get_setting('operating_hours', '09:00 - 22:00 WIB'),
            'pickup_address': get_setting('pickup_address', 'Jl. Pemuda Kreatif No. 45, Serang')
        }

    # Register Blueprints
    from blueprints.public import public_bp
    from blueprints.admin import admin_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')

    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.environ.get('PORT', 5050))
    app.run(host='127.0.0.1', port=port, debug=True)
