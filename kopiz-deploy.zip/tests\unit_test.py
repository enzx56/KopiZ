import unittest
from datetime import datetime, timedelta
from app import create_app
from models import db, Product, PreOrder, Order, OrderItem, Customer, User

class KopiZTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()

        with self.app.app_context():
            db.create_all()
            # Setup product
            p = Product(
                name="Test Kopi Aren",
                slug="test-kopi-aren",
                price=15000,
                status="READY",
                track_inventory=True,
                stock_quantity=10,
                is_active=True
            )
            db.session.add(p)
            db.session.commit()
            self.product_id = p.id

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_public_pages_load(self):
        """Test home and menu pages load successfully"""
        r_home = self.client.get('/')
        self.assertEqual(r_home.status_code, 200)
        self.assertIn(b'KopiZ', r_home.data)

        r_menu = self.client.get('/menu')
        self.assertEqual(r_menu.status_code, 200)
        self.assertIn(b'Test Kopi Aren', r_menu.data)

    def test_checkout_server_validation_and_tamper_protection(self):
        """Test that server recalculates prices from DB regardless of client input"""
        tampered_payload = {
            "name": "Budi Santoso",
            "phone": "081234567890",
            "order_type": "REGULAR",
            "items": [
                {
                    "product_id": self.product_id,
                    "name": "Test Kopi Aren",
                    "price": 100, # Client attempts to tamper price to Rp100
                    "quantity": 2
                }
            ]
        }
        res = self.client.post('/api/checkout/process', json=tampered_payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        order_code = data['order_code']

        with self.app.app_context():
            order = Order.query.filter_by(order_code=order_code).first()
            self.assertIsNotNone(order)
            # Must be 15.000 * 2 = 30.000, not tampered 200
            self.assertEqual(order.total_amount, 30000)
            self.assertEqual(order.items[0].unit_price, 15000)
            self.assertEqual(order.status, 'PENDING')

    def test_preorder_quota_exhaustion(self):
        """Test Pre-Order rejects checkout when quota is exceeded"""
        with self.app.app_context():
            now = datetime.utcnow()
            po = PreOrder(
                name="Test Batch PO",
                slug="test-batch-po",
                starts_at=now - timedelta(days=1),
                ends_at=now + timedelta(days=2),
                pickup_at=now + timedelta(days=3),
                quota_units=5,
                reserved_units=4, # Only 1 left
                status="OPEN"
            )
            db.session.add(po)
            db.session.commit()
            po_id = po.id

        # Order 2 units when only 1 is left
        payload = {
            "name": "Siti Rahma",
            "phone": "081987654321",
            "order_type": "PREORDER",
            "pre_order_id": po_id,
            "items": [
                {
                    "product_id": self.product_id,
                    "name": "Test Kopi Aren",
                    "price": 15000,
                    "quantity": 2
                }
            ]
        }
        res = self.client.post('/api/checkout/process', json=payload)
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertFalse(data['success'])
        self.assertIn("sisa kuota", data['message'].lower())

if __name__ == '__main__':
    unittest.main()
