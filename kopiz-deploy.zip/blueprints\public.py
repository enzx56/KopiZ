from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from datetime import datetime
from models import db, Product, Category, PreOrder, PreOrderProduct, Order, OrderItem, Customer, OrderStatusHistory, Setting
from helpers import generate_order_code, normalize_phone, build_whatsapp_link, get_setting

public_bp = Blueprint('public', __name__)

@public_bp.route('/')
def home():
    featured_products = Product.query.filter_by(is_active=True, is_featured=True, archived_at=None).limit(4).all()
    active_po = PreOrder.query.filter(PreOrder.status.in_(['OPEN', 'SCHEDULED'])).order_by(PreOrder.starts_at.asc()).first()
    categories = Category.query.filter_by(is_active=True).order_by(Category.sort_order.asc()).all()
    hero_title = get_setting('hero_title', 'KopiZ — Kopinya Gen-Z')
    hero_subtitle = get_setting('hero_subtitle', 'Kopi Berkualitas, Harga Pas.')
    announcement = get_setting('announcement_text', '')

    return render_template('public/home.html',
                           featured_products=featured_products,
                           active_po=active_po,
                           categories=categories,
                           hero_title=hero_title,
                           hero_subtitle=hero_subtitle,
                           announcement=announcement)

@public_bp.route('/menu')
def menu():
    category_slug = request.args.get('kategori', '')
    search_query = request.args.get('q', '').strip()
    status_filter = request.args.get('status', '')
    sort_by = request.args.get('sort', 'default')

    query = Product.query.filter_by(is_active=True, archived_at=None)

    if category_slug:
        cat = Category.query.filter_by(slug=category_slug).first()
        if cat:
            query = query.filter_by(category_id=cat.id)

    if search_query:
        query = query.filter(Product.name.ilike(f"%{search_query}%"))

    if status_filter:
        query = query.filter_by(status=status_filter)

    if sort_by == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort_by == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort_by == 'name_asc':
        query = query.order_by(Product.name.asc())
    else:
        query = query.order_by(Product.is_featured.desc(), Product.id.asc())

    products = query.all()
    categories = Category.query.filter_by(is_active=True).order_by(Category.sort_order.asc()).all()

    return render_template('public/menu.html',
                           products=products,
                           categories=categories,
                           current_category=category_slug,
                           search_query=search_query,
                           status_filter=status_filter,
                           sort_by=sort_by)

@public_bp.route('/menu/<slug>')
def menu_detail(slug):
    product = Product.query.filter_by(slug=slug, is_active=True, archived_at=None).first_or_404()
    related = Product.query.filter(
        Product.category_id == product.category_id,
        Product.id != product.id,
        Product.is_active == True,
        Product.archived_at == None
    ).limit(3).all()
    return render_template('public/menu_detail.html', product=product, related=related)

@public_bp.route('/po')
def pre_orders():
    pos = PreOrder.query.filter(PreOrder.status.in_(['OPEN', 'SCHEDULED', 'SOLD_OUT'])).order_by(PreOrder.starts_at.asc()).all()
    return render_template('public/pre_orders.html', pre_orders=pos)

@public_bp.route('/po/<slug>')
def pre_order_detail(slug):
    po = PreOrder.query.filter_by(slug=slug).first_or_404()
    return render_template('public/pre_order_detail.html', po=po)

@public_bp.route('/keranjang')
def cart():
    return render_template('public/cart.html')

@public_bp.route('/checkout')
def checkout():
    po_id = request.args.get('po_id')
    po_context = None
    if po_id:
        po_context = PreOrder.query.get(po_id)
    return render_template('public/checkout.html', po_context=po_context)

# API Endpoint: Validasi Keranjang Realtime dari Database
@public_bp.route('/api/cart/validate', methods=['POST'])
def validate_cart():
    data = request.get_json() or {}
    items = data.get('items', [])
    validated_items = []
    total_amount = 0

    for it in items:
        prod_id = it.get('product_id')
        qty = int(it.get('quantity', 1))
        prod = Product.query.get(prod_id)
        if prod and prod.is_active and prod.archived_at is None:
            # Check availability
            is_available = prod.status in ['READY', 'PO']
            if prod.track_inventory and prod.stock_quantity < qty:
                is_available = False

            subtotal = prod.price * qty
            total_amount += subtotal
            validated_items.append({
                'product_id': prod.id,
                'name': prod.name,
                'price': prod.price,
                'quantity': qty,
                'subtotal': subtotal,
                'image_path': prod.image_path,
                'status': prod.status,
                'is_available': is_available
            })

    return jsonify({
        'success': True,
        'items': validated_items,
        'total_amount': total_amount
    })

# API Endpoint: Proses Checkout Aman & Transaksi Database Atomik
@public_bp.route('/api/checkout/process', methods=['POST'])
def process_checkout():
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Data checkout tidak valid.'}), 400

    name = data.get('name', '').strip()
    phone = data.get('phone', '').strip()
    notes = data.get('notes', '').strip()
    pickup_time = data.get('pickup_time', '').strip()
    order_type = data.get('order_type', 'REGULAR') # REGULAR or PREORDER
    pre_order_id = data.get('pre_order_id')
    items_data = data.get('items', [])

    if not name or not phone:
        return jsonify({'success': False, 'message': 'Nama dan nomor WhatsApp wajib diisi.'}), 400

    if not items_data or len(items_data) == 0:
        return jsonify({'success': False, 'message': 'Keranjang pesanan masih kosong.'}), 400

    norm_phone = normalize_phone(phone)
    if len(norm_phone) < 9:
        return jsonify({'success': False, 'message': 'Nomor WhatsApp tidak valid.'}), 400

    # Memulai Transaksi Database Atomik
    try:
        # 1. Deduplikasi / Simpan Pelanggan
        customer = Customer.query.filter_by(normalized_phone=norm_phone).first()
        if not customer:
            customer = Customer(
                name=name,
                phone=phone,
                normalized_phone=norm_phone
            )
            db.session.add(customer)
            db.session.flush()
        else:
            customer.name = name
            customer.phone = phone

        # 2. Validasi Pre-Order jika ada
        target_po = None
        total_units_requested = sum(int(it.get('quantity', 1)) for it in items_data)

        if order_type == 'PREORDER' and pre_order_id:
            target_po = PreOrder.query.with_for_update().get(pre_order_id)
            if not target_po:
                return jsonify({'success': False, 'message': 'Sesi Pre-Order tidak ditemukan.'}), 400

            now = datetime.utcnow()
            if target_po.status != 'OPEN' or now < target_po.starts_at or now > target_po.ends_at:
                return jsonify({'success': False, 'message': 'Periode Pre-Order ini sudah ditutup atau belum dibuka.'}), 400

            if target_po.reserved_units + total_units_requested > target_po.quota_units:
                return jsonify({
                    'success': False,
                    'message': f'Mohon maaf, sisa kuota Pre-Order hanya tersisa {target_po.quota_units - target_po.reserved_units} unit.'
                }), 400

            # Reservasikan kuota
            target_po.reserved_units += total_units_requested
            if target_po.reserved_units >= target_po.quota_units:
                target_po.status = 'SOLD_OUT'

        # 3. Validasi Produk & Hitung Ulang Total di Server
        server_total = 0
        order_items_to_save = []

        for item_in in items_data:
            pid = item_in.get('product_id')
            qty = int(item_in.get('quantity', 1))
            if qty <= 0:
                continue

            product = Product.query.with_for_update().get(pid)
            if not product or not product.is_active or product.archived_at is not None:
                db.session.rollback()
                return jsonify({'success': False, 'message': f'Produk "{item_in.get("name")}" sudah tidak tersedia.'}), 400

            if product.status == 'SOLD_OUT':
                db.session.rollback()
                return jsonify({'success': False, 'message': f'Produk "{product.name}" sedang habis stok.'}), 400

            # Cek stok inventory reguler
            if order_type == 'REGULAR' and product.track_inventory:
                if product.stock_quantity < qty:
                    db.session.rollback()
                    return jsonify({'success': False, 'message': f'Stok produk "{product.name}" tidak mencukupi (sisa: {product.stock_quantity}).'}), 400

            # Gunakan harga resmi dari database server (Anti-Tampering)
            unit_price = product.price
            subtotal = unit_price * qty
            server_total += subtotal

            order_item = OrderItem(
                product_id=product.id,
                product_name_snapshot=product.name,
                sku_snapshot=product.sku,
                unit_price=unit_price,
                quantity=qty,
                subtotal=subtotal
            )
            order_items_to_save.append(order_item)

        # 4. Generate Kode Pesanan Unik
        order_code = generate_order_code()

        # Parse pickup_at jika disediakan
        parsed_pickup = None
        if pickup_time:
            try:
                parsed_pickup = datetime.fromisoformat(pickup_time)
            except Exception:
                parsed_pickup = None
        elif target_po:
            parsed_pickup = target_po.pickup_at

        # 5. Buat Record Order Baru
        order = Order(
            order_code=order_code,
            customer_id=customer.id,
            order_type=order_type,
            pre_order_id=target_po.id if target_po else None,
            order_date=datetime.utcnow(),
            pickup_at=parsed_pickup,
            subtotal=server_total,
            discount_amount=0,
            total_amount=server_total,
            status='PENDING',
            customer_notes=notes
        )
        db.session.add(order)
        db.session.flush()

        for oi in order_items_to_save:
            oi.order_id = order.id
            db.session.add(oi)

        # 6. Catat Histori Status Awal
        history = OrderStatusHistory(
            order_id=order.id,
            from_status=None,
            to_status='PENDING',
            changed_by='Pelanggan (Checkout)',
            note='Pesanan baru dibuat melalui website publik.'
        )
        db.session.add(history)

        db.session.commit()

        # Buat link WhatsApp siap kirim
        wa_biz = get_setting('whatsapp_number', '081234567890')
        wa_link = build_whatsapp_link(wa_biz, order, customer, order_items_to_save)

        return jsonify({
            'success': True,
            'order_code': order_code,
            'whatsapp_url': wa_link,
            'redirect_url': url_for('public.order_status', order_code=order_code)
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Terjadi kesalahan server: {str(e)}'}), 500

# Halaman Status & Konfirmasi Pesanan Pelanggan (Tanpa Bocor ID Berurutan)
@public_bp.route('/pesanan/<order_code>')
def order_status(order_code):
    order = Order.query.filter_by(order_code=order_code).first_or_404()
    customer = Customer.query.get(order.customer_id)
    items = OrderItem.query.filter_by(order_id=order.id).all()
    wa_biz = get_setting('whatsapp_number', '081234567890')
    wa_link = build_whatsapp_link(wa_biz, order, customer, items)

    return render_template('public/order_status.html',
                           order=order,
                           customer=customer,
                           items=items,
                           whatsapp_link=wa_link)

# Halaman-halaman Statis Informasi KopiZ
@public_bp.route('/tentang')
def about():
    return render_template('public/static_pages.html', page_type='tentang')

@public_bp.route('/cara-pesan')
def how_to_order():
    return render_template('public/static_pages.html', page_type='cara_pesan')

@public_bp.route('/kontak')
def contact():
    return render_template('public/static_pages.html', page_type='kontak')

@public_bp.route('/kebijakan-privasi')
def privacy_policy():
    return render_template('public/static_pages.html', page_type='privasi')

@public_bp.route('/syarat-ketentuan')
def terms():
    return render_template('public/static_pages.html', page_type='syarat')
