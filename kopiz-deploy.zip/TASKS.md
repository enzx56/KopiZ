# Roadmap & Status Tugas KopiZ

- [x] **Fase 0: Audit & Perencanaan**
  - [x] Periksa lingkungan eksekusi (Python 3.14, SQLite 3.50+).
  - [x] Susun `README.md`, `ARCHITECTURE.md`, dan `TASKS.md`.
  - [x] Rancang arsitektur Flask + SQLAlchemy + SQLite3 + Tailwind CSS.

- [x] **Fase 1: Fondasi & Basis Data**
  - [x] Inisialisasi model SQLAlchemy dengan schema terindeks (`models.py`).
  - [x] Buat skrip setup dan seeding otomatis (`setup.py`).
  - [x] 3 Produk awal: Butterscotch (Rp15.000), Kopi Susu Gula Aren (Rp15.000), Salted Caramel (Rp17.000).
  - [x] Akun admin default: `admin@kopiz.id` (password: `admin123`).

- [x] **Fase 2: UI Publik & Katalog**
  - [x] Design system warna Coffee + Cream (`#3A2418`, `#6F4E37`, `#B9824A`, `#FFF8EF`, `#F3E5D0`).
  - [x] Beranda (`/`): Hero, moto, menu terpopuler, batch PO aktif, alur pesan ringkas.
  - [x] Katalog Menu (`/menu`): Pencarian realtime, filter kategori, status ketersediaan, pengurutan harga/nama.
  - [x] Detail Menu (`/menu/<slug>`): Informasi racikan, kuantitas, status stok.
  - [x] Halaman Statis: Tentang KopiZ, Cara Pesan, Kontak, Kebijakan Privasi, Syarat & Ketentuan.

- [x] **Fase 3: Autentikasi & Dashboard Admin**
  - [x] Login & Logout Admin yang aman dengan hashing Werkzeug/bcrypt (`/admin/login`).
  - [x] Proteksi middleware login di seluruh route `/admin/*`.
  - [x] Dashboard Metrik Operasional Realtime: Order Hari Ini, Pending, Sedang Dibuat, Omset Selesai, Menu Terlaris.
  - [x] CRUD Produk & Kategori dengan upload foto, status, dan inventory tracking.
  - [x] Manajemen Pengaturan Brand & Kontak (Nomor WhatsApp, Instagram, Jam Buka, Alamat).

- [x] **Fase 4: Keranjang & Checkout Transaksional**
  - [x] Keranjang belanja sisi klien (`static/js/cart.js`) dengan localStorage & counter badge.
  - [x] Halaman Checkout tanpa akun: nama, WhatsApp, jam pickup, catatan.
  - [x] Validasi server-side anti manipulasi harga (harga divalidasi ulang dari database).
  - [x] Transaksi atomik pembuatan order & item dengan snapshot harga historis.
  - [x] Generator kode unik pesanan (misal `KPZ-261026-XXXXX`).
  - [x] Format pesan resmi WhatsApp sesuai PRD Bagian 9 & status tracker publik (`/pesanan/<orderCode>`).

- [x] **Fase 5: Sistem Pre-Order (PO) & Manajemen Pesanan**
  - [x] Halaman publik Pre-Order (`/po` dan `/po/<slug>`) dengan jadwal, kuota, dan banner.
  - [x] Pencegahan overselling kuota PO dengan atomic lock `with_for_update()`.
  - [x] Admin Pre-Order: Buat batch baru, atur kuota unit, ubah status (OPEN, CLOSED, dll).
  - [x] Admin Orders: Filter status, detail order, update alur status & pencatatan log riwayat.
  - [x] Data Pelanggan teragregasi otomatis dari pesanan.

- [x] **Fase 6: Laporan Bisnis & Ekspor CSV**
  - [x] Filter laporan tanggal, status, dan jenis pesanan.
  - [x] Ringkasan metrik penjualan selesai (COMPLETED), total nilai kotor, dan total unit terjual.
  - [x] Ekspor CSV dengan UTF-8 BOM untuk kompatibilitas Microsoft Excel & aplikasi spreadsheet.

- [x] **Fase 7: Verifikasi, Pengujian & Dokumentasi Final**
  - [x] Test suite integrasi (`tests/unit_test.py`) lulus 100%.
  - [x] Konfigurasi `.env.example` dan dokumentasi deployment siap pakai.
