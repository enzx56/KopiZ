from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
from app import create_app
from models import db, User, Category, Product, PreOrder, PreOrderProduct, Setting

def run_setup():
    app = create_app()
    with app.app_context():
        print("[INFO] Menginisialisasi database KopiZ...")
        db.create_all()

        # 1. Admin Default
        admin_email = "admin@kopiz.id"
        existing_admin = User.query.filter_by(email=admin_email).first()
        if not existing_admin:
            admin = User(
                name="Admin KopiZ",
                email=admin_email,
                password_hash=generate_password_hash("admin123"),
                role="admin",
                is_active=True
            )
            db.session.add(admin)
            print(f"[OK] Akun admin dibuat: {admin_email} (password: admin123)")

        # 2. Pengaturan Default Sesuai PRD
        default_settings = [
            ("brand_name", "KopiZ"),
            ("brand_tagline", "Kopinya Gen-Z"),
            ("brand_moto", "Kopi Berkualitas, Harga Pas"),
            ("whatsapp_number", "081234567890"),
            ("instagram_handle", "kopiz.id"),
            ("instagram_url", "https://instagram.com/kopiz.id"),
            ("operating_hours", "Senin - Minggu: 09:00 - 22:00 WIB"),
            ("pickup_address", "Jl. Pemuda Kreatif No. 45, Serang - Banten"),
            ("hero_title", "KopiZ — Kopinya Gen-Z"),
            ("hero_subtitle", "Kopi Berkualitas, Harga Pas. Diracik khusus buat menemani produktivitas dan nongkrong asikmu."),
            ("announcement_text", "Promo Pre-Order Spesial Batch Weekend dibuka! Kuota terbatas."),
        ]

        for key, val in default_settings:
            setting = Setting.query.filter_by(key=key).first()
            if not setting:
                db.session.add(Setting(key=key, value=val, is_public=True))
        print("[OK] Pengaturan default tersimpan.")

        # 3. Kategori Awal
        categories_data = [
            ("Signature Coffee", "signature-coffee", "Menu racikan kopi khas KopiZ yang paling favorit."),
            ("Milk Base & Latte", "milk-base-latte", "Kombinasi espresso lembut dengan susu segar pilihan."),
            ("Non-Coffee", "non-coffee", "Pilihan minuman segar non-kopi untuk semua suasana.")
        ]
        
        cat_map = {}
        for idx, (cname, cslug, cdesc) in enumerate(categories_data):
            cat = Category.query.filter_by(slug=cslug).first()
            if not cat:
                cat = Category(name=cname, slug=cslug, description=cdesc, sort_order=idx)
                db.session.add(cat)
                db.session.flush()
            cat_map[cslug] = cat.id
        print("[OK] Kategori awal terverifikasi.")

        # 4. Produk Awal Sesuai PRD Bagian 8
        initial_products = [
            {
                "name": "Butterscotch",
                "slug": "butterscotch",
                "sku": "KPZ-BSC-01",
                "short_description": "Kopi creamy dengan rasa butterscotch yang manis legit",
                "description": "Perpaduan double shot espresso pilihan dengan sirup butterscotch premium dan fresh milk. Lembut, wangi karamel mentega khas yang bikin nagih.",
                "price": 15000,
                "category_id": cat_map["signature-coffee"],
                "status": "READY",
                "track_inventory": True,
                "stock_quantity": 50,
                "is_featured": True,
                "image_path": "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80"
            },
            {
                "name": "Kopi Susu Gula Aren",
                "slug": "kopi-susu-gula-aren",
                "sku": "KPZ-AREN-02",
                "short_description": "Kopi susu dengan rasa gula aren yang khas dan autentik",
                "description": "Espresso bold berpadu seimbang dengan manisnya gula aren murni asli nusantara dan susu creamy segar. Teman setia belajar dan kerja santai.",
                "price": 15000,
                "category_id": cat_map["signature-coffee"],
                "status": "READY",
                "track_inventory": True,
                "stock_quantity": 60,
                "is_featured": True,
                "image_path": "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=600&q=80"
            },
            {
                "name": "Salted Caramel",
                "slug": "salted-caramel",
                "sku": "KPZ-SCAR-03",
                "short_description": "Kopi dengan perpaduan caramel dan sentuhan asin yang seimbang",
                "description": "Sensasi rasa manis gurih khas saus caramel berpadu sedikit sea-salt dan espresso aromatik. Rasa kaya yang bikin momen nongkrong makin seru.",
                "price": 17000,
                "category_id": cat_map["signature-coffee"],
                "status": "READY",
                "track_inventory": True,
                "stock_quantity": 40,
                "is_featured": True,
                "image_path": "https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=600&q=80"
            }
        ]

        product_objects = []
        for pdata in initial_products:
            prod = Product.query.filter_by(slug=pdata["slug"]).first()
            if not prod:
                prod = Product(**pdata)
                db.session.add(prod)
                db.session.flush()
                print(f"[OK] Produk dibuat: {prod.name} ({prod.price})")
            product_objects.append(prod)

        # 5. Pre-Order (PO) Spesial Batch Contoh
        po_slug = "po-batch-spesial-weekend"
        existing_po = PreOrder.query.filter_by(slug=po_slug).first()
        if not existing_po:
            now = datetime.utcnow()
            po = PreOrder(
                name="PO Batch Spesial Weekend Gen-Z",
                slug=po_slug,
                description="Pre-order batch fresh brew botol literan & cup dingin untuk santai akhir pekan. Kuota terbatas 30 botol!",
                banner_path="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1200&q=80",
                starts_at=now - timedelta(days=1),
                ends_at=now + timedelta(days=5),
                pickup_at=now + timedelta(days=6),
                quota_units=30,
                reserved_units=0,
                status="OPEN",
                published_at=now
            )
            db.session.add(po)
            db.session.flush()

            # Hubungkan produk PO
            for prod in product_objects:
                pop = PreOrderProduct(
                    pre_order_id=po.id,
                    product_id=prod.id,
                    price=prod.price,
                    max_quantity_per_order=5
                )
                db.session.add(pop)
            print("[OK] Pre-Order batch awal dibuat.")

        db.session.commit()
        print("[SUCCESS] Database setup & seeding selesai dengan sukses!")

if __name__ == '__main__':
    run_setup()
