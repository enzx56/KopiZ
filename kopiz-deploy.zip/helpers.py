import re
import random
import string
from datetime import datetime
import zoneinfo

def format_rupiah(value):
    if value is None:
        return "Rp0"
    try:
        val = int(value)
        return f"Rp{val:,.0f}".replace(",", ".")
    except (ValueError, TypeError):
        return f"Rp{value}"

def format_datetime(dt, format_str="%d %b %Y, %H:%M"):
    if not dt:
        return "-"
    try:
        # Standardize to Jakarta Timezone
        if isinstance(dt, str):
            dt = datetime.fromisoformat(dt)
        return dt.strftime(format_str)
    except Exception:
        return str(dt)

def slugify(text):
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    text = re.sub(r'^-+|-+$', '', text)
    return text

def normalize_phone(phone_str):
    """Normalize phone number to international 62 format without plus or symbols"""
    if not phone_str:
        return ""
    digits = re.sub(r'\D', '', str(phone_str))
    if digits.startswith('0'):
        digits = '62' + digits[1:]
    elif digits.startswith('8'):
        digits = '62' + digits
    return digits

def generate_order_code():
    """Generate unique and secure alphanumeric order tracking code"""
    now_part = datetime.utcnow().strftime("%y%m%d")
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"KPZ-{now_part}-{random_part}"

def get_setting(key, default=""):
    from models import Setting
    item = Setting.query.filter_by(key=key).first()
    return item.value if item else default

def build_whatsapp_link(phone_business, order, customer, items):
    """
    Format message based on PRD Section 9:
    Halo KopiZ! Saya ingin memesan.

    Kode Pesanan: {order_code}
    Nama: {customer_name}
    Nomor WhatsApp: {customer_phone}

    Pesanan:
    {item_name} x {quantity} — {subtotal}

    Total: {total_amount}
    Jenis: {regular_or_preorder}
    Pengambilan: {pickup_datetime}
    Catatan: {notes}

    Mohon konfirmasi pesanan saya. Terima kasih.
    """
    clean_biz_phone = normalize_phone(phone_business)
    
    item_lines = []
    for it in items:
        subtotal_str = format_rupiah(it.subtotal)
        item_lines.append(f"{it.product_name_snapshot} x {it.quantity} — {subtotal_str}")
    
    items_block = "\n".join(item_lines)
    pickup_str = format_datetime(order.pickup_at) if order.pickup_at else "Langsung di Kedai / Sesuai Jadwal"
    notes_str = order.customer_notes if order.customer_notes else "-"
    order_type_str = "Pre-Order (PO)" if order.order_type == "PREORDER" else "Pesanan Reguler"

    msg = (
        f"Halo KopiZ! Saya ingin memesan.\n\n"
        f"Kode Pesanan: {order.order_code}\n"
        f"Nama: {customer.name}\n"
        f"Nomor WhatsApp: {customer.phone}\n\n"
        f"Pesanan:\n{items_block}\n\n"
        f"Total: {format_rupiah(order.total_amount)}\n"
        f"Jenis: {order_type_str}\n"
        f"Pengambilan: {pickup_str}\n"
        f"Catatan: {notes_str}\n\n"
        f"Mohon konfirmasi pesanan saya. Terima kasih."
    )

    from urllib.parse import quote
    return f"https://wa.me/{clean_biz_phone}?text={quote(msg)}"
