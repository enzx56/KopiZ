// KopiZ Local Cart Management
const CART_KEY = 'kopiz_cart_items';

const CartManager = {
    getItems: function() {
        try {
            return JSON.parse(localStorage.getItem(CART_KEY)) || [];
        } catch (e) {
            return [];
        }
    },

    saveItems: function(items) {
        localStorage.setItem(CART_KEY, JSON.stringify(items));
        this.updateBadge();
    },

    addItem: function(product) {
        const items = this.getItems();
        const existingIndex = items.findIndex(item => item.product_id === product.product_id);

        if (existingIndex > -1) {
            items[existingIndex].quantity += (product.quantity || 1);
        } else {
            items.push({
                product_id: product.product_id,
                name: product.name,
                price: product.price,
                image_path: product.image_path,
                quantity: product.quantity || 1
            });
        }

        this.saveItems(items);
        this.showToast(`Berhasil menambahkan ${product.name} ke keranjang!`);
    },

    updateQuantity: function(productId, qty) {
        let items = this.getItems();
        if (qty <= 0) {
            items = items.filter(it => it.product_id !== productId);
        } else {
            const it = items.find(it => it.product_id === productId);
            if (it) it.quantity = qty;
        }
        this.saveItems(items);
    },

    removeItem: function(productId) {
        let items = this.getItems();
        items = items.filter(it => it.product_id !== productId);
        this.saveItems(items);
    },

    clear: function() {
        localStorage.removeItem(CART_KEY);
        this.updateBadge();
    },

    updateBadge: function() {
        const items = this.getItems();
        const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
        const badge = document.getElementById('cart-badge-count');
        if (badge) {
            if (totalCount > 0) {
                badge.innerText = totalCount;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        }
    },

    showToast: function(message) {
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-5 right-5 z-50 bg-primary text-white px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 border border-accent/40 text-sm font-semibold transition-transform transform duration-300';
        toast.innerHTML = `<span>☕</span> <span>${message}</span>`;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    CartManager.updateBadge();
});
