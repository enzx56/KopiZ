# Arsitektur Sistem KopiZ (Python / Flask)

## 1. Pilihan Arsitektur
- **Runtime & Language**: Python 3.14 (native SQLite 3.50+ & standard library tools)
- **Framework**: Flask 3.1 (Arsitektur Blueprint modular)
- **Database**: SQLite3 via SQLAlchemy (Foreign Keys diaktifkan secara eksplisit, transaction lock via `with_for_update()` / `db.session.begin_nested()` untuk kuota Pre-Order).
- **Template Engine**: Jinja2 dengan custom formatters (IDR currency `format_rupiah`, Asia/Jakarta time parser `format_datetime`).
- **Styling**: Tailwind CSS + Font Inter + Palet Coffee & Cream (`#3A2418`, `#6F4E37`, `#B9824A`, `#FFF8EF`, `#F3E5D0`).

## 2. Struktur Modul & Folder
```text
kopiz/
├── app.py                  # Entrypoint aplikasi Flask
├── setup.py                # Inisialisasi DB, migrasi skema & seed data awal
├── config.py               # Konfigurasi aplikasi & secret key
├── models.py               # Definisi Model SQLAlchemy (User, Category, Product, Customer, PreOrder, Order, OrderItem, dll)
├── helpers.py              # Helper formatting rupiah, slugify, nomor WhatsApp, generate order code
├── blueprints/
│   ├── public.py           # Route publik (home, menu, detail, cart, checkout, tracking pesanan, statis)
│   ├── admin.py            # Route admin (auth, dashboard, CRUD produk/kategori, PO, pesanan, pelanggan, laporan, settings)
├── templates/
│   ├── base.html           # Layout utama publik (Navbar, Footer, Toast/Alert)
│   ├── admin/
│   │   ├── base.html       # Layout admin (Sidebar, Topbar)
│   │   ├── login.html      # Login admin
│   │   ├── dashboard.html  # Metrik & Grafik operasional
│   │   ├── products/       # List, Tambah, Edit produk
│   │   ├── categories/     # List & Kelola kategori
│   │   ├── pre_orders/     # List, Tambah, Edit, Detail PO
│   │   ├── orders/         # List pesanan, Filter, Detail & Ganti status
│   │   ├── customers/      # List & Rekap pelanggan
│   │   ├── reports/        # Laporan & Tombol Export CSV
│   │   └── settings/       # Pengaturan WhatsApp, Instagram, Jam Buka, Konten Hero
│   ├── public/
│   │   ├── home.html       # Beranda
│   │   ├── menu.html       # Katalog menu & filter
│   │   ├── menu_detail.html# Detail produk
│   │   ├── pre_orders.html # List PO aktif
│   │   ├── pre_order_detail.html # Detail PO & form pesan
│   │   ├── cart.html       # Keranjang belanja
│   │   ├── checkout.html   # Form checkout tanpa akun
│   │   ├── order_status.html # Pelacak pesanan via order code
│   │   └── static_pages.html # Tentang, Cara Pesan, Kebijakan, Syarat
├── static/
│   ├── css/
│   ├── js/
│   │   └── cart.js         # State keranjang belanja di browser (localStorage)
│   ├── images/
│   │   ├── kopiz_logo.svg  # Logo KopiZ
│   │   └── coffee_placeholder.jpg
│   └── uploads/            # Direktori upload file gambar
├── tests/
│   └── test_kopiz.py       # Test suite integrasi: auth, order validation, PO quota locking, export
├── README.md
├── ARCHITECTURE.md
└── TASKS.md
```

## 3. Pencegahan Overselling & Integritas Transaksi
- Kuota PO dihitung per unit produk (`quota_units` vs `reserved_units`).
- Setiap checkout PO dieksekusi dalam transaksi database terisolasi: `PreOrder` dicek statusnya (`OPEN`), periode waktu (`starts_at` <= now <= `ends_at`), serta sisa kuota (`reserved_units + qty <= quota_units`).
- Jika melebihi kuota, transaksi di-rollback secara otomatis dan pesan kesalahan informatif diberikan ke pelanggan.
- Snapshot harga dan nama produk selalu disimpan pada tabel `order_items` sehingga perubahan harga di masa mendatang tidak akan mengubah riwayat keuangan order lama.
