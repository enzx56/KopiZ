# KopiZ — Kopinya Gen-Z ☕

**Tagline:** Kopinya Gen-Z  
**Moto:** Kopi Berkualitas, Harga Pas  
**Platform:** Penjualan Kopi, Pre-Order, Operasional, dan Analitik

---

## ☕ Ringkasan Aplikasi
KopiZ adalah platform e-commerce dan operasional kedai kopi modern yang mencakup:
1. **Website Pelanggan Publik**:
   - Beranda interaktif dengan palette Coffee + Cream (`#3A2418`, `#6F4E37`, `#B9824A`, `#FFF8EF`, `#F3E5D0`).
   - Katalog menu dengan filter kategori, pencarian, dan status ketersediaan realtime.
   - Halaman Pre-Order (PO) dengan jadwal, kuota tersisa, dan validasi server-side atomic.
   - Keranjang belanja dan Checkout instan tanpa wajib registrasi akun.
   - Generator deep link WhatsApp siap kirim dengan format pesanan rapi & kode pelacak acak unik.
   - Pelacak status pesanan publik via kode unik aman (`/pesanan/{orderCode}`).
   - Halaman statis: Tentang KopiZ, Cara Pesan, Kontak, Kebijakan Privasi, Syarat & Ketentuan.

2. **Dashboard Operasional Admin**:
   - Autentikasi aman session-based dengan proteksi route.
   - Metrik operasional realtime (Order Hari Ini, Menunggu Konfirmasi, Sedang Dibuat, Selesai, Omset Periode, Produk Terlaris).
   - CRUD Produk & Kategori dengan status (`READY`, `PO`, `SOLD_OUT`, `INACTIVE`), soft-archival untuk integritas transaksi.
   - Manajemen Pre-Order (PO) dengan kuota unit, jadwal mulai/selesai/pickup, dan status (`DRAFT`, `SCHEDULED`, `OPEN`, `CLOSED`, `SOLD_OUT`, `COMPLETED`, `CANCELLED`).
   - Manajemen Pesanan: Update alur status (`PENDING` -> `CONFIRMED` -> `PREPARING` -> `READY_FOR_PICKUP` -> `COMPLETED`/`CANCELLED`), catatan internal, log riwayat status, dan struk/ringkasan cetak.
   - Data Pelanggan teragregasi otomatis dari pesanan.
   - Laporan & Analitik dengan filter tanggal, status, tipe pesanan, serta ekspor CSV ber-BOM kompatibel Excel.
   - Manajemen Pengaturan Konten & Brand (Hero, WhatsApp bisnis, Instagram, Jam Buka, Alamat Pickup).

---

## 🛠️ Stack Teknologi
- **Backend**: Python 3.14 + Flask 3.1 + Jinja2 + SQLAlchemy 2.1
- **Database**: SQLite3 bawaan Python (dengan transaksi ACID terisolasi untuk kuota PO)
- **Frontend**: Jinja2 Templates + Tailwind CSS + Lucide Icons
- **Keamanan**: Werkzeug Security (pbkdf2:sha256), Session aman, Sanitasi input & Validasi Server-Side
- **Zona Waktu & Format**: Asia/Jakarta (WIB) & Rupiah (IDR)

---

## 🚀 Panduan Menjalankan Proyek

### 1. Prasyarat
- Python 3.10+ (sudah terinstall Python 3.14)

### 2. Setup Database & Seeding
```bash
python setup.py
```
Akun Admin Default:
- **Email**: `admin@kopiz.id`
- **Password**: `admin123`

### 3. Menjalankan Server
```bash
python app.py
```
Akses di browser:
- Website Publik: `http://localhost:5000`
- Dashboard Admin: `http://localhost:5000/admin/login`
